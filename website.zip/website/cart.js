document.addEventListener("DOMContentLoaded", function () {
    const cartItemsContainer = document.getElementById("cart-items");
    const totalPriceElement = document.getElementById("total-price");

    // Function to load cart from localStorage
    function loadCart() {
        const cart = JSON.parse(localStorage.getItem("cart")) || [];
        displayCart(cart);
    }

    // Function to display cart items
    function displayCart(cart) {
        cartItemsContainer.innerHTML = ""; // Clear current cart items
        let totalPrice = 0;

        cart.forEach((item, index) => {
            const cartItemElement = document.createElement("div");
            cartItemElement.classList.add("cart-item");
            cartItemElement.innerHTML = `
                <div class="cart-item-info">
                    <h4>${item.name}</h4>
                    <p>₹${item.price}</p>
                </div>
                <button class="remove-btn" data-index="${index}">Remove</button>
            `;
            cartItemsContainer.appendChild(cartItemElement);

            // Calculate total price
            totalPrice += item.price;
        });

        totalPriceElement.textContent = `${totalPrice}`; // Update total price
    }

    // Remove item from cart
    cartItemsContainer.addEventListener("click", function (event) {
        if (event.target.classList.contains("remove-btn")) {
            const index = event.target.dataset.index;
            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            cart.splice(index, 1); // Remove item at index
            localStorage.setItem("cart", JSON.stringify(cart)); // Update localStorage
            loadCart(); // Re-load the cart
        }
    });

    // Load cart when the page loads
    loadCart();

    // Checkout button now redirects to order.html
    document.getElementById("checkout-btn").addEventListener("click", function () {
        window.location.href = "order.html";
    });
});

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("order-form");
  const slipSection = document.getElementById("order-slip");

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    // Get form values
    const name = document.getElementById("customer-name").value;
    const address = document.getElementById("address").value;
    const phone = document.getElementById("phone").value;

    // Get cart from localStorage
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const slipItems = document.getElementById("slip-items");
    let total = 0;

    slipItems.innerHTML = ""; // clear previous
    cart.forEach(item => {
      const li = document.createElement("li");
      li.textContent = `${item.name} - ₹${item.price}`;
      slipItems.appendChild(li);
      total += item.price;
    });

    // Fill slip details
    document.getElementById("slip-name").textContent = name;
    document.getElementById("slip-address").textContent = address;
    document.getElementById("slip-phone").textContent = phone;
    document.getElementById("slip-total").textContent = total;

    // Show slip section
    slipSection.classList.remove("hidden");

    // Clear cart (optional)
    localStorage.removeItem("cart");

    // Reset form
    form.reset();
  });
});

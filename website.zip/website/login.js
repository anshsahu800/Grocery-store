document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.getElementById("login-form");
  const loginMessage = document.getElementById("login-message");

  const users = [
    { username: "user1", password: "password1" },
    { username: "user2", password: "password2" }
  ];

  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
      localStorage.setItem("loggedInUser", username); // 🔐 Save login info
      loginMessage.textContent = "Login successful! Redirecting...";
      loginMessage.style.color = "green";


      setTimeout(() => {
        window.location.href = "index.html"; // ✅ Redirect to homepage
      }, 1000);
    } else {
      loginMessage.textContent = "Invalid credentials. Try again.";
      loginMessage.style.color = "red";
    }
  });
});

document.addEventListener("DOMContentLoaded", function () {
  // Product List
  const products = [
    { id: 1, name: "Apple", category: "Fruits", price: 50.0, image: "images/apple.jpg" },
    { id: 2, name: "Banana", category: "Fruits", price: 44.2, image: "images/banana.jpg" },
    { id: 3, name: "Carrot", category: "Vegetables", price: 30.0, image: "images/carrot.jpg" },
    { id: 4, name: "Milk", category: "Dairy", price: 60.0, image: "images/milk.jpg" },
    { id: 5, name: "Tomato", category: "Vegetables", price: 25.5, image: "images/tomato.jpg" },
    { id: 6, name: "Orange", category: "Fruits", price: 45.0, image: "images/orange.jpg" },
    { id: 7, name: "Cheese", category: "Dairy", price: 44.5, image: "images/cheese.jpg" },
    { id: 8, name: "Broccoli", category: "Vegetables", price: 15.8, image: "images/broccoli.jpg" },
    { id: 9, name: "Grapes", category: "Fruits", price: 30.2, image: "images/grapes.jpg" },
    { id: 10, name: "Potato", category: "Vegetables", price: 20.0, image: "images/potato.jpg" },
    { id: 11, name: "Yogurt", category: "Dairy", price: 25.8, image: "images/yogurt.jpg" },
    { id: 12, name: "Strawberry", category: "Fruits", price: 35.5, image: "images/strawberry.jpg" },
    { id: 13, name: "Lettuce", category: "Vegetables", price: 45.2, image: "images/lettuce.jpg" },
    { id: 14, name: "Butter", category: "Dairy", price: 45.0, image: "images/butter.jpg" },
    { id: 15, name: "Pineapple", category: "Fruits", price: 32.8, image: "images/pineapple.jpg" }
  ];

  const productsContainer = document.querySelector(".products");
  const cartItemsList = document.getElementById("cart-items");

  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Load all products
  function loadProducts() {
    if (!productsContainer) return;
    products.forEach(product => {
      const productCard = document.createElement("div");
      productCard.classList.add("product-card");
      productCard.innerHTML = `
        <img src="${product.image}" alt="${product.name}">
        <h3>${product.name}</h3>
        <p>Category: ${product.category}</p>
        <p>Price: ₹${product.price.toFixed(2)}</p>
        <button class="add-to-cart" onclick="addToCart(${product.id})">Add to Cart</button>
      `;
      productsContainer.appendChild(productCard);
    });
  }

  // Add to cart function
  window.addToCart = function (productId) {
    const product = products.find(p => p.id === productId);
    cart.push(product);
    localStorage.setItem("cart", JSON.stringify(cart));
    alert(`${product.name} has been added to the cart!`);
  };

  // Cart page items loading
  function loadCart() {
    if (!cartItemsList) return;
    cartItemsList.innerHTML = '';
    if (cart.length > 0) {
      cart.forEach(item => {
        const li = document.createElement("li");
        li.textContent = `${item.name} - ₹${item.price.toFixed(2)}`;
        cartItemsList.appendChild(li);
      });
    } else {
      cartItemsList.innerHTML = "<li>Your cart is empty.</li>";
    }
  }

  if (cartItemsList) loadCart();
  loadProducts();

  // Show login/logout icon based on status
  const loginSection = document.getElementById("login-section");
  const userInfo = document.getElementById("user-info");

  const loggedInUser = localStorage.getItem("loggedInUser");
  if (loggedInUser) {
    loginSection.style.display = "none";
    userInfo.classList.remove("hidden");
  } else {
    loginSection.style.display = "block";
    userInfo.classList.add("hidden");
  }

  // Logout button
  const logoutBtn = document.getElementById("logout-btn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", function (e) {
      e.preventDefault();
      localStorage.removeItem("loggedInUser");
      location.reload();
    });
  }
});
